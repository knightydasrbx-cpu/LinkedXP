package com.example.sharedxp;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

public class SharedXpMod implements ModInitializer {
    @Override
    public void onInitialize() {
        ServerTickEvents.END_SERVER_TICK.register(SharedXpMod::syncLevels);
    }

    private static void syncLevels(MinecraftServer server) {
        var players = server.getPlayerList().getPlayers();
        if (players.isEmpty()) return;

        long totalXp = 0;
        for (ServerPlayer player : players) {
            totalXp += player.totalExperience;
        }

        int targetLevel = levelForTotalXp(totalXp);
        for (ServerPlayer player : players) {
            player.setExperienceLevels(targetLevel);
            player.setExperienceProgress(0.0F);
        }
    }

    private static int levelForTotalXp(long xp) {
        int level = 0;
        while (level < 1000 && xp >= xpNeededForNextLevel(level)) {
            xp -= xpNeededForNextLevel(level);
            level++;
        }
        return level;
    }

    private static int xpNeededForNextLevel(int level) {
        if (level >= 30) return 112 + (level - 30) * 9;
        if (level >= 15) return 37 + (level - 15) * 5;
        return 17 + level * 3;
    }
}